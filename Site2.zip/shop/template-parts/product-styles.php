<!-- product styles -->


<style>.u-section-1 .u-sheet-1 {
  min-height: 595px;
}
.u-section-1 .u-product-1 {
  min-height: 495px;
  margin-top: 50px;
  margin-bottom: 50px;
}
.u-section-1 .u-container-layout-1 {
  padding: 30px;
}
.u-section-1 .u-gallery-1 {
  width: 540px;
  height: 433px;
  margin: 0 auto 0 0;
}
.u-section-1 .u-over-slide-1 {
  min-height: 100px;
  padding: 10px;
}
.u-section-1 .u-over-slide-2 {
  min-height: 100px;
  padding: 10px;
}
.u-section-1 .u-carousel-thumbnails-1 {
  padding-right: 10px;
  padding-top: 0;
  padding-left: 0;
}
.u-section-1 .u-carousel-thumbnail-1 {
  width: 100px;
  height: 100px;
}
.u-section-1 .u-carousel-thumbnail-2 {
  width: 100px;
  height: 100px;
}
.u-section-1 .u-carousel-control-1 {
  position: absolute;
  left: 110px;
  width: 40px;
  height: 40px;
  background-image: none;
}
.u-section-1 .u-carousel-control-2 {
  position: absolute;
  width: 40px;
  height: 40px;
  background-image: none;
  left: auto;
  right: 0;
}
.u-section-1 .u-text-1 {
  margin: -353px auto 0 598px;
}
.u-section-1 .u-product-price-1 {
  margin: 30px auto 0 598px;
}
.u-section-1 .u-text-2 {
  margin: 30px auto 0 598px;
}
.u-section-1 .u-btn-1 {
  border-style: solid;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 2px;
  margin: 30px auto 78px 598px;
  padding: 10px 43px 10px 42px;
}
@media (max-width: 1199px) {
  .u-section-1 .u-sheet-1 {
    min-height: 519px;
  }
  .u-section-1 .u-product-1 {
    height: auto;
    min-height: 419px;
  }
  .u-section-1 .u-gallery-1 {
    width: 471px;
    height: 357px;
  }
  .u-section-1 .u-text-1 {
    width: auto;
    margin-top: -328px;
    margin-left: 515px;
  }
  .u-section-1 .u-product-price-1 {
    margin-left: 515px;
  }
  .u-section-1 .u-text-2 {
    width: auto;
    margin-right: 0;
    margin-left: 515px;
  }
  .u-section-1 .u-btn-1 {
    margin-bottom: 0;
    margin-left: 515px;
  }
}
@media (max-width: 991px) {
  .u-section-1 .u-product-1 {
    min-height: 926px;
  }
  .u-section-1 .u-gallery-1 {
    width: 660px;
    height: 553px;
  }
  .u-section-1 .u-text-1 {
    margin-top: 40px;
    margin-left: 110px;
  }
  .u-section-1 .u-product-price-1 {
    margin-top: 20px;
    margin-left: 110px;
  }
  .u-section-1 .u-text-2 {
    margin-left: 110px;
  }
  .u-section-1 .u-btn-1 {
    margin-top: 27px;
    margin-left: 110px;
  }
}
@media (max-width: 767px) {
  .u-section-1 .u-sheet-1 {
    min-height: 898px;
  }
  .u-section-1 .u-product-1 {
    margin-bottom: -68px;
    min-height: 798px;
  }
  .u-section-1 .u-container-layout-1 {
    padding-left: 10px;
    padding-right: 10px;
  }
  .u-section-1 .u-gallery-1 {
    width: 520px;
    height: 415px;
  }
  .u-section-1 .u-text-1 {
    margin-right: 287px;
    margin-left: 0;
  }
  .u-section-1 .u-product-price-1 {
    margin-left: 0;
  }
  .u-section-1 .u-text-2 {
    margin-right: auto;
    margin-left: 0;
  }
  .u-section-1 .u-btn-1 {
    margin-left: 0;
  }
}
@media (max-width: 575px) {
  .u-section-1 .u-sheet-1 {
    min-height: 681px;
  }
  .u-section-1 .u-product-1 {
    margin-bottom: 50px;
    min-height: 581px;
  }
  .u-section-1 .u-gallery-1 {
    width: 320px;
    height: 209px;
  }
  .u-section-1 .u-text-1 {
    margin-top: 35px;
    margin-right: 0;
  }
}
</style>
