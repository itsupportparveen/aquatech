<!-- footer styles -->

<style> .u-footer {
  background-image: none;
}
.u-footer .u-sheet-1 {
  min-height: 120px;
}
@media (max-width: 1199px) {
  .u-footer .u-sheet-1 {
    min-height: 99px;
  }
}
@media (max-width: 991px) {
  .u-footer .u-sheet-1 {
    min-height: 76px;
  }
}
@media (max-width: 767px) {
  .u-footer .u-sheet-1 {
    min-height: 57px;
  }
}
@media (max-width: 575px) {
  .u-footer .u-sheet-1 {
    min-height: 36px;
  }
}</style>
